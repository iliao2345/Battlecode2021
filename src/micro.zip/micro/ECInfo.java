package micro;
import battlecode.common.*;

public class ECInfo {
	public static RobotController rc;
	public static int open_spawn_tiles_required;
	public static RobotType[] ALL_ROBOTTYPES = new RobotType[] {RobotType.ENLIGHTENMENT_CENTER, RobotType.POLITICIAN, RobotType.SLANDERER, RobotType.MUCKRAKER};
	public static int GUARD_SPAWN_COST_THRESHOLD = 1000;
	
	public static IntCycler ids = null;
	public static IntCycler types = null;  // 0 for EC, 1 for politician, 2 for slanderer, 3 for muckraker
	public static int n_ids = 0;
	public static int passive_income;
	public static int[] embezzler_ids;
	public static int[] embezzler_incomes;
	public static int embezzle_income;
	public static int total_income;
	public static double total_income_per_build;
	public static int open_spawn_tiles;
	public static double unit_price;
	public static int sampled_ec_influence = 0;
	public static int sampled_politician_influence = 0;
	public static int sampled_muckraker_influence = 0;
	public static boolean guard_flag;
	public static boolean desired_guard_flag;
	public static IntCycler slanderer_ids = null;
	public static boolean enough_guards;
	public static boolean finish_ecs_off_flag;
	public static int finish_ecs_off_timer = 0;
	public static IntCycler guard_ids = null;
	public static int n_guard_ids = 0;
	
	public static void initialize() throws GameActionException {
		embezzler_ids = new int[GameConstants.EMBEZZLE_NUM_ROUNDS];
		embezzler_incomes = new int[GameConstants.EMBEZZLE_NUM_ROUNDS];
		int n_spawn_tiles_on_map = 0;
		for (Direction dir:Math2.UNIT_DIRECTIONS) {
			if (rc.onTheMap(rc.getLocation().add(dir))) {
				n_spawn_tiles_on_map++;
			}
		}
		open_spawn_tiles_required = Math.min(n_spawn_tiles_on_map, (int) Math.ceil(11*rc.sensePassability(rc.getLocation())/2)+1);
	}
	
	public static void update() throws GameActionException {
		finish_ecs_off_timer = Math.max(0, finish_ecs_off_timer-1);
		double total_sampled_ec_influence = 0;
		double total_sampled_politician_influence = 0;
		double total_sampled_muckraker_influence = 0;
		int min_enemy_ec_influence = Integer.MAX_VALUE;
		if (ids!=null) {
			for (int i=0; i<50; i++) {
				if (!rc.canGetFlag(ids.data)) {
					if (ids.next==ids) {
						ids = null;
						types = null;
						n_ids = 0;
						break;
					}
					ids.last.next = ids.next;
					ids.next.last = ids.last;
					types.last.next = types.next;
					types.next.last = types.last;
					n_ids--;
				}
				else {
					int flag = rc.getFlag(ids.data);
					if (flag>>23==1 && (flag>>17)%16!=0) {
						int influence = (int) Math.ceil(2*(Math.exp(((double)((flag>>17)%16))/2)-1));
						switch ((flag>>21)%4) {
						case 0: {
							total_sampled_ec_influence += influence;
							if (Math.random()<influence/total_sampled_ec_influence) {sampled_ec_influence = influence;}
							min_enemy_ec_influence = Math.min(min_enemy_ec_influence, influence);
							if (min_enemy_ec_influence*1.3 < Info.conviction) {
								finish_ecs_off_timer = n_ids/50+1;
							}
							break;}
						case 1: {
							total_sampled_politician_influence += influence;
							if (Math.random()<influence/total_sampled_politician_influence) {sampled_politician_influence = influence;}
							break;}
						case 3: {
							total_sampled_muckraker_influence += influence;
							if (Math.random()<influence/total_sampled_muckraker_influence) {sampled_muckraker_influence = influence;}
							break;}
						}
					}
					else if (flag>>22==1) {
						if (n_guard_ids<=15) {
							boolean found = false;
							for (int j=n_guard_ids; --j>=0;) {
								if (guard_ids.data==ids.data) {
									found = true; break;
								}
								guard_ids = guard_ids.next;
							}
							if (!found) {
								guard_ids = new IntCycler(ids.data, guard_ids);
								n_guard_ids++;
							}
						}
					}
				}
				ids = ids.next;
				types = types.next;
			}
		}
		enough_guards = true;
		for (int i=n_guard_ids; --i>=0;) {
			if (rc.canGetFlag(guard_ids.data)) {
				if (rc.getFlag(guard_ids.data)>>22==1) {
					enough_guards = enough_guards && rc.getFlag(guard_ids.data)%2==1;
					System.out.println("GUARD_ID: " + guard_ids.data);
					guard_ids = guard_ids.next;
					continue;
				}
			}
			if (guard_ids.next==guard_ids) {
				guard_ids = null;
				n_guard_ids = 0;
			}
			else {
				guard_ids.last.next = guard_ids.next;
				guard_ids.next.last = guard_ids.last;
				guard_ids = guard_ids.next;
				n_guard_ids--;
			}
		}
		if (n_guard_ids==0) {enough_guards = false;}
		System.out.println("N_GUARD_IDS: " + n_guard_ids);
		passive_income = (int) Math.ceil(GameConstants.PASSIVE_INFLUENCE_RATIO_ENLIGHTENMENT_CENTER*Math.sqrt(Info.round_num));
		embezzler_ids[Info.round_num%GameConstants.EMBEZZLE_NUM_ROUNDS] = 0;
		embezzler_incomes[Info.round_num%GameConstants.EMBEZZLE_NUM_ROUNDS] = 0;
		embezzle_income = 0;
		for (int i=GameConstants.EMBEZZLE_NUM_ROUNDS; --i>=0;) {
			if (rc.canGetFlag(embezzler_ids[i])) {
				embezzle_income += embezzler_incomes[i];
			}
		}
		total_income = passive_income + embezzle_income;
		total_income_per_build = ECInfo.total_income*RobotType.ENLIGHTENMENT_CENTER.actionCooldown/Info.tile_cost;
		open_spawn_tiles = 0;
		for (Direction dir:Math2.UNIT_DIRECTIONS) {
			if (rc.canSenseLocation(Info.loc.add(dir))) {
				RobotInfo robot = rc.senseRobotAtLocation(Info.loc.add(dir));
				if (robot==null || robot.team==Info.friendly) {
					open_spawn_tiles++;
				}
			}
		}
		System.out.println(open_spawn_tiles);
		System.out.println(open_spawn_tiles_required);
		unit_price = total_income_per_build*2;// + Info.conviction/200.0;
		desired_guard_flag = n_ids>150;
		boolean friendly_slanderer_exists = false;
		while (slanderer_ids!=null) {
			if (!rc.canGetFlag(slanderer_ids.data)) {
				if (slanderer_ids.next==slanderer_ids) {
					slanderer_ids = null;
					friendly_slanderer_exists = false;
					break;
				}
				slanderer_ids.last.next = slanderer_ids.next;
				slanderer_ids.next.last = slanderer_ids.last;
				slanderer_ids = slanderer_ids.next;
			}
			else {
				friendly_slanderer_exists = true;
				break;
			}
		}
		guard_flag = (desired_guard_flag || friendly_slanderer_exists) && Info.round_num<1300;
		finish_ecs_off_flag = finish_ecs_off_timer>0;
		if (finish_ecs_off_flag) {rc.setIndicatorDot(Info.loc, 255, 0, 0);}
		if (embezzle_income/3>0) {rc.bid(embezzle_income/3);}
	}

}
