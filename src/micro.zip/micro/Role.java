package micro;
import battlecode.common.*;

public class Role {
	public static RobotController rc;
	public static boolean is_relay_chain = false;
	public static boolean is_guard = false;
	
	public static void attach_to_relay_chain() throws GameActionException {
		if (!is_relay_chain) {
			is_relay_chain = true;
			is_guard = false;
			RelayChain.source_dist = 31;
			RelayChain.target_dist = 255;
			RelayChain.update();
		}
	}
	
	public static void detach_from_relay_chain() throws GameActionException {
		if (is_relay_chain) {
			is_relay_chain = false;
		}
	}
	
	public static void become_guard() throws GameActionException {
		if (!Role.is_guard) {
			is_relay_chain = false;
			is_guard = true;
			Guard.update();
		}
	}
}
