package micro;
import battlecode.common.*;

public class Politician {
	public static RobotController rc;
	
	public static void act() throws GameActionException {
		if ((Role.is_guard || Info.n_friendly_ecs+Info.n_friendly_slanderers>0) && Info.ec_needs_guards) {
			Role.become_guard();
		}
		else {
			Role.attach_to_relay_chain();
		}
		if (Info.finish_ecs_off && Info.conviction>13) {
			if (rc.senseNearbyRobots(Info.loc, 1, Info.enemy).length>0) {
				rc.empower(1); return;
			}
		}
		CombatInfo.compute_self_empower_gains();
		double best_gains = (CombatInfo.optimal_empower_gains>0)?CombatInfo.optimal_empower_gains:Integer.MIN_VALUE;  // don't use conditional if we want to force suicide to save friendly units or disallow conversions
		RobotInfo largest_nearby_politician = null;
		int largest_conviction = Integer.MIN_VALUE;
		for (int i=Info.n_friendly_politicians; --i>=0;) {
			if (Info.friendly_politicians[i].conviction>largest_conviction) {
				largest_nearby_politician = Info.friendly_politicians[i];
				largest_conviction = largest_nearby_politician.conviction;
			}
		}
		for (int i=Info.n_enemy_politicians; --i>=0;) {
			if (Info.enemy_politicians[i].conviction>largest_conviction) {
				largest_nearby_politician = Info.enemy_politicians[i];
				largest_conviction = largest_nearby_politician.conviction;
			}
		}
		double[][] move_gains = new double[3][3];
		boolean[][] negative_gain_tiles = new boolean[3][3];
		if (largest_nearby_politician!=null) {
			move_gains = CombatInfo.compute_move_gains(largest_nearby_politician);
		}
		else {
			best_gains = Math.max(best_gains, 0);
		}
		for (Direction dir:Direction.allDirections()) {
			for (int i=Info.n_friendly_ecs; --i>=0;) {
				if (Info.loc.add(dir).isWithinDistanceSquared(Info.friendly_ecs[i].location, 2)) {
					move_gains[dir.dx+1][dir.dy+1]-=Info.unit_price;
				}
			}
			for (int i=Info.n_enemy_ecs; --i>=0;) {
				if (Info.loc.add(dir).isWithinDistanceSquared(Info.enemy_ecs[i].location, 2)) {
					move_gains[dir.dx+1][dir.dy+1]+=Info.unit_price;
				}
			}
			if (dir==Direction.CENTER || rc.canMove(dir)) {
				best_gains = Math.max(best_gains, move_gains[dir.dx+1][dir.dy+1]);
				negative_gain_tiles[dir.dx+1][dir.dy+1] = move_gains[dir.dx+1][dir.dy+1]<0;
			}
		}
		if (best_gains==CombatInfo.optimal_empower_gains && best_gains>0) {  // use != if we want to force suicide to save friendly units or disallow conversions
			rc.empower(CombatInfo.optimal_empower_radius); return;
		}
		if (best_gains!=0) {
			for (Direction dir:Direction.allDirections()) {
				if (dir==Direction.CENTER || rc.canMove(dir)) {
					if (best_gains==move_gains[dir.dx+1][dir.dy+1]) {
						Role.detach_from_relay_chain();
						Action.move(dir); return;
					}
				}
			}
		}
		if (best_gains==CombatInfo.optimal_empower_gains && best_gains<0) {  // use != if we want to force suicide to save friendly units or disallow conversions
			return;
		}
		if (Role.is_relay_chain) {
			Role.attach_to_relay_chain();
			if (Info.n_enemy_ecs>0) {
				boolean enemy_ec_buried = true;
				for (Direction dir:Math2.UNIT_DIRECTIONS) {
					MapLocation check_loc = Info.enemy_ecs[0].location.add(dir);
					if (rc.canSenseLocation(check_loc)) {
						if (rc.senseRobotAtLocation(check_loc)==null) {
							enemy_ec_buried = false;
							break;
						}
					}
				}
				if (!enemy_ec_buried) {RelayChain.lock_target(Info.enemy_ecs[0].location);}
			}
			if (Info.finish_ecs_off && Info.conviction>13) {
				if (Info.n_enemy_ecs>0) {RelayChain.lock_target(Info.enemy_ecs[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_politicians>0) {RelayChain.lock_target(Info.enemy_politicians[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_slanderers>0) {RelayChain.lock_target(Info.enemy_slanderers[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_muckrakers>0) {RelayChain.lock_target(Info.enemy_muckrakers[0].location);}
			}
			if (RelayChain.extend(negative_gain_tiles)) {return;}
			return;
		}
		else if (Role.is_guard) {
			RobotInfo closest_enemy_muckraker = Info.closest_robot(Info.enemy, RobotType.MUCKRAKER);
			if (closest_enemy_muckraker==null || !Info.loc.isWithinDistanceSquared(closest_enemy_muckraker.location, 9)) {
				Guard.defend(); return;
			}
			else if (closest_enemy_muckraker!=null) {
				int r_squared = 9;
				CombatInfo.compute_self_empower_gains();
				if (CombatInfo.damage_9 > closest_enemy_muckraker.conviction && CombatInfo.kills_9>0) {rc.empower(9); return;}
				if (CombatInfo.damage_8 > closest_enemy_muckraker.conviction && CombatInfo.kills_8>0) {rc.empower(8); return;}
				if (CombatInfo.damage_5 > closest_enemy_muckraker.conviction && CombatInfo.kills_5>0) {rc.empower(5); return;}
				if (CombatInfo.damage_4 > closest_enemy_muckraker.conviction && CombatInfo.kills_4>0) {rc.empower(4); return;}
				if (CombatInfo.damage_2 > closest_enemy_muckraker.conviction && CombatInfo.kills_2>0) {rc.empower(2); return;}
				if (CombatInfo.damage_1 > closest_enemy_muckraker.conviction && CombatInfo.kills_1>0) {rc.empower(1); return;}
				if (closest_enemy_muckraker.location.isWithinDistanceSquared(Guard.last_seen_defense_location, 20)) {
					rc.empower(Info.loc.distanceSquaredTo(closest_enemy_muckraker.location)); return;
				}
				else {
					Pathing.stick(closest_enemy_muckraker.location, new boolean[3][3]); return;
				}
			}
		}
	}
	
	public static void pause() {
		
	}

}
