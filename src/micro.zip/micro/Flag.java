package micro;
import battlecode.common.*;

public class Flag {
	public static RobotController rc;
	public static int[] bits = new int[] {24};
	public static int[] values = new int[] {0};
	
	public static void set() {
		if (Info.type==RobotType.ENLIGHTENMENT_CENTER) {
			bits = new int[] {1, 1, 17, 5};
			values = new int[] {ECInfo.guard_flag?1:0, ECInfo.finish_ecs_off_flag?1:0, 0, Math.min(31, Math.max(0, (int)(4*Math.log(ECInfo.unit_price/4.0+1))))};
		}
		else if (Info.type==RobotType.POLITICIAN || Info.type==RobotType.MUCKRAKER) {
			int sample_type = 0;
			switch (Info.sample_type) {
			case POLITICIAN: {sample_type = 1; break;}
			case SLANDERER: {sample_type = 2; break;}
			case MUCKRAKER: {sample_type = 3; break;}
			}
			if (Role.is_relay_chain) {
				bits = new int[] {1, 2, 4, 5, 8, 4};
				values = new int[] {
						1,
						sample_type,
						(int)Math.ceil(2*Math.log(((double)Info.sample_influence)/2+1)),
						RelayChain.source_dist,
						(int)(RelayChain.target_dist),
						(int)(((16*RelayChain.target_angle/Math.PI/2)+0.5)%16)
				};
			}
			else if (Role.is_guard) {
				bits = new int[] {2, 21, 1};
				values = new int[] {
						1,
						0,
						Guard.enough_guards?1:0
				};
			}
			else {
				bits = new int[] {24};
				values = new int[] {
						0
				};
			}
		}
		else if (Info.type==RobotType.SLANDERER) {
			bits = new int[] {3, 21};
			values = new int[] {
					1,
					0
			};
		}
	}
	public static void display() throws GameActionException {
		rc.setFlag(encode(bits, values));
		bits = new int[] {24};
		values = new int[] {0};
	}
	public static int encode(int[] bits, int[] values) {
		int flag = 0;
		for (int i=0; i<bits.length; i++) {
			flag = (flag<<bits[i]) + values[i];
		}
		return flag;
	}
}
