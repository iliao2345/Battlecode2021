package micro;
import battlecode.common.*;

public class Muckraker {
	public static RobotController rc;
	
	public static void act() throws GameActionException {
		RobotInfo closest_enemy_slanderer = Info.closest_robot(Info.enemy, RobotType.SLANDERER);
    	if (closest_enemy_slanderer!=null) {
    		if (Info.loc.distanceSquaredTo(closest_enemy_slanderer.location)<=RobotType.MUCKRAKER.actionRadiusSquared) {
    			Action.expose(closest_enemy_slanderer);
    		}
    	}
		double best_gains = Integer.MIN_VALUE;
		RobotInfo largest_nearby_politician = null;
		int largest_conviction = Integer.MIN_VALUE;
		for (int i=Info.n_friendly_politicians; --i>=0;) {
			if (Info.friendly_politicians[i].conviction>largest_conviction) {
				largest_nearby_politician = Info.friendly_politicians[i];
				largest_conviction = largest_nearby_politician.conviction;
			}
		}
		for (int i=Info.n_enemy_politicians; --i>=0;) {
			if (Info.enemy_politicians[i].conviction>largest_conviction) {
				largest_nearby_politician = Info.enemy_politicians[i];
				largest_conviction = largest_nearby_politician.conviction;
			}
		}
		double[][] move_gains = new double[3][3];
		boolean[][] negative_gain_tiles = new boolean[3][3];
		if (largest_nearby_politician!=null) {
			move_gains = CombatInfo.compute_move_gains(largest_nearby_politician);
		}
		else {
			best_gains = Math.max(best_gains, 0);
		}
		for (Direction dir:Direction.allDirections()) {
			for (int i=Info.n_friendly_ecs; --i>=0;) {
				if (Info.loc.add(dir).isWithinDistanceSquared(Info.friendly_ecs[i].location, 2)) {
					move_gains[dir.dx+1][dir.dy+1]-=Info.unit_price;
				}
			}
			for (int i=Info.n_enemy_ecs; --i>=0;) {
				if (Info.loc.add(dir).isWithinDistanceSquared(Info.enemy_ecs[i].location, 2)) {
					move_gains[dir.dx+1][dir.dy+1]+=Info.unit_price;
				}
			}
			if (dir==Direction.CENTER || rc.canMove(dir)) {
				best_gains = Math.max(best_gains, move_gains[dir.dx+1][dir.dy+1]);
				negative_gain_tiles[dir.dx+1][dir.dy+1] = move_gains[dir.dx+1][dir.dy+1]<0;
			}
		}
		if (best_gains!=0) {
			for (Direction dir:Direction.allDirections()) {
				if (dir==Direction.CENTER || rc.canMove(dir)) {
					if (best_gains==move_gains[dir.dx+1][dir.dy+1]) {
						Role.detach_from_relay_chain();
						Action.move(dir); return;
					}
				}
			}
		}
		else if (closest_enemy_slanderer!=null) {
			Role.detach_from_relay_chain();
			Pathing.target(closest_enemy_slanderer.location, negative_gain_tiles, 1);
			return;
		}
		else {
			Role.attach_to_relay_chain();
			if (Info.n_enemy_ecs>0) {
				boolean enemy_ec_buried = true;
				for (Direction dir:Math2.UNIT_DIRECTIONS) {
					MapLocation check_loc = Info.enemy_ecs[0].location.add(dir);
					if (rc.canSenseLocation(check_loc)) {
						if (rc.senseRobotAtLocation(check_loc)==null) {
							enemy_ec_buried = false;
							break;
						}
					}
				}
				if (!enemy_ec_buried) {RelayChain.lock_target(Info.enemy_ecs[0].location);}
			}
			if (Info.finish_ecs_off && Info.conviction>13) {
				if (Info.n_enemy_ecs>0) {RelayChain.lock_target(Info.enemy_ecs[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_politicians>0) {RelayChain.lock_target(Info.enemy_politicians[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_slanderers>0) {RelayChain.lock_target(Info.enemy_slanderers[0].location);}
				else if (Info.round_num>1300 && Info.n_enemy_muckrakers>0) {RelayChain.lock_target(Info.enemy_muckrakers[0].location);}
			}
			if (RelayChain.extend(negative_gain_tiles)) {return;}
			return;
		}
		throw new GameActionException(null, "Best gain action computed but not found!");
	}
	
	public static void pause() {
		
	}

}
