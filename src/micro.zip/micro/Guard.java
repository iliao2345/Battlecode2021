package micro;
import battlecode.common.*;

public class Guard {
	public static int DEFENSE_INNER_RADIUS_SQUARED = 5;
	public static int DEFENSE_OUTER_RADIUS_SQUARED = 16;
	public static RobotController rc;
	
	public static MapLocation last_seen_defense_location = null;
	public static boolean enough_guards;
	public static double guard_pressure_dx;
	public static double guard_pressure_dy;
	public static boolean can_be_within_guard_range;
	public static boolean[][] too_close_or_far;
	public static MapLocation closest_defense_location;
	public static int closest_defense_distance_squared;
	
	public static void update() throws GameActionException {
		closest_defense_distance_squared = Integer.MAX_VALUE;
		closest_defense_location = null;
		for (int i=Info.n_tracked_friendly_ecs; --i>=0;) {
			MapLocation tracked_ec_loc = new MapLocation(Info.tracked_friendly_ec_x.data, Info.tracked_friendly_ec_y.data);
			if (Info.loc.distanceSquaredTo(tracked_ec_loc)<closest_defense_distance_squared) {
				closest_defense_distance_squared = Info.loc.distanceSquaredTo(tracked_ec_loc);
				closest_defense_location = tracked_ec_loc;
				last_seen_defense_location = closest_defense_location;
			}
			Info.tracked_friendly_ec_ids = Info.tracked_friendly_ec_ids.next;
			Info.tracked_friendly_ec_x = Info.tracked_friendly_ec_x.next;
			Info.tracked_friendly_ec_y = Info.tracked_friendly_ec_y.next;
		}
		RobotInfo closest_friendly_slanderer = Info.closest_robot(Info.friendly, RobotType.SLANDERER);
		if (closest_friendly_slanderer!=null) {
			if (Info.loc.distanceSquaredTo(closest_friendly_slanderer.location)<closest_defense_distance_squared) {
				closest_defense_distance_squared = Info.loc.distanceSquaredTo(closest_friendly_slanderer.location);
				closest_defense_location = closest_friendly_slanderer.location;
				last_seen_defense_location = closest_defense_location;
			}
		}
		if (closest_defense_location==null) {
			if (last_seen_defense_location==null) {Role.attach_to_relay_chain(); return;}
			else {
				closest_defense_distance_squared = Info.loc.distanceSquaredTo(last_seen_defense_location);
				closest_defense_location = last_seen_defense_location;
			}
		}
		rc.setIndicatorLine(Info.loc, last_seen_defense_location, 0, 0, 255);
		can_be_within_guard_range = false;
		too_close_or_far = new boolean[3][3];
		for (Direction dir:Direction.allDirections()) {
			int r_squared = Info.loc.add(dir).distanceSquaredTo(closest_defense_location);
			too_close_or_far[dir.dx+1][dir.dy+1] = r_squared <= DEFENSE_INNER_RADIUS_SQUARED || r_squared >= DEFENSE_OUTER_RADIUS_SQUARED;
			if ((rc.canMove(dir) || dir==Direction.CENTER) && !too_close_or_far[dir.dx+1][dir.dy+1]) {
				can_be_within_guard_range = true;
			}
		}
		int n_guards = 0;
		guard_pressure_dx = 0;
		guard_pressure_dy = 0;
		for (int i=Info.n_friendly_politicians; --i>=0;) {
			if (rc.getFlag(Info.friendly_politicians[i].ID)>>22==1 && Clock.getBytecodesLeft()>1700) {
				MapLocation repel_loc = Info.friendly_politicians[i].location;
				guard_pressure_dx -= 1000*(repel_loc.x-Info.x)/Info.loc.distanceSquaredTo(repel_loc);
				guard_pressure_dy -= 1000*(repel_loc.y-Info.y)/Info.loc.distanceSquaredTo(repel_loc);
				rc.setIndicatorLine(Info.loc, repel_loc, 0, 128, 0);
				n_guards++;
			}
		}
		enough_guards = n_guards >= 5;
	}
	
	public static void defend() throws GameActionException {
		if (can_be_within_guard_range) {
			Pathing.stick(Info.loc.translate((int)(guard_pressure_dx+0.5), (int)(guard_pressure_dy+0.5)), too_close_or_far); return;
		}
		else if (closest_defense_distance_squared<DEFENSE_INNER_RADIUS_SQUARED) {  // too close
			if (closest_defense_distance_squared<=1) {  // within slanderer lattice
				int closest_ec_distance = Integer.MAX_VALUE;
				MapLocation ec_location = new MapLocation(0, 0);  // guaranteed to be far from everything else
				for (int i=Info.n_tracked_friendly_ecs; --i>=0;) {
					MapLocation tracked_ec_loc = new MapLocation(Info.tracked_friendly_ec_x.data, Info.tracked_friendly_ec_y.data);
					if (Info.loc.distanceSquaredTo(tracked_ec_loc)<closest_ec_distance) {
						closest_ec_distance = Info.loc.distanceSquaredTo(tracked_ec_loc);
						ec_location = tracked_ec_loc;
					}
					Info.tracked_friendly_ec_ids = Info.tracked_friendly_ec_ids.next;
					Info.tracked_friendly_ec_x = Info.tracked_friendly_ec_x.next;
					Info.tracked_friendly_ec_y = Info.tracked_friendly_ec_y.next;
				}
				Direction momentum_direction = Info.last_move_direction;  // if cannot avoid odd tiles and friendly EC, try to take an outgoing line
				if (Math.random()<0.5) {momentum_direction = momentum_direction.rotateLeft().rotateLeft();}
				if (Math.random()<0.5) {momentum_direction = momentum_direction.rotateRight().rotateRight();}
				Direction best_direction = null;
				int lowest_cost = Integer.MAX_VALUE;
				for (Direction dir:Math2.UNIT_DIRECTIONS) {
					int cost = -dir.dx*momentum_direction.dx-dir.dy*momentum_direction.dy;
					boolean storage_location = ((Info.x+dir.dx-1)/2+(Info.y+dir.dy-1)/2)%2==1 && Info.loc.add(dir).isWithinDistanceSquared(ec_location, 10);
					boolean outgoing_line = ((Info.x+dir.dx-1)/2+(Info.y+dir.dy-1)/2)%2==0;
					if (outgoing_line && !storage_location && (rc.canMove(dir)||dir==Direction.CENTER) && (best_direction==null || cost<lowest_cost)) {
						best_direction = dir;
						lowest_cost = cost;
					}
				}
				if (best_direction!=null) {Action.move(best_direction); return;}
				int n_possible_directions = 0;
				best_direction = null;  // worst case move randomly
				for (Direction dir:Math2.UNIT_DIRECTIONS) {
					if (rc.canMove(dir) && Math.random()<1/(n_possible_directions+1)) {
						best_direction = dir;
					}
				}
				if (best_direction!=null) {Action.move(best_direction); return;}
			}
			else {
				Pathing.target(closest_defense_location, new boolean[3][3], -1); return;
			}
		}
		else  {  // too far
			Pathing.target(closest_defense_location, new boolean[3][3], 1); return;
		}
	}
}
